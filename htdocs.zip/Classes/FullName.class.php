<?php
class FullName
{
  public static function get($name,$surname)
  {
    return $name ." ". $surname;
  }
}
?>